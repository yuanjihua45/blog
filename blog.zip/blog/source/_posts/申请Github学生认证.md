---
title: 申请Github学生认证
date: 2024-04-08 11:38:31
tags:
categories: 小记
cover: https://s21.ax1x.com/2024/04/08/pFLK2oq.png
top_img: https://s21.ax1x.com/2024/04/08/pFLK2oq.png
copyright:
copyright_author: ？
copyright_author_href: ？
copyright_url: 
copyright_info:

---

![](https://s21.ax1x.com/2024/04/08/pFLK2oq.png)
